package classesprincipais;
/**
 * Interface escrita especialmente para guardar os servicos numa colecao contida na classe hotel.
 * @author Jeferson Rolim Holanda
 *
 */
public interface Servico {
	
	public double totalAPagar();
	
	public String getReferencia();

}
